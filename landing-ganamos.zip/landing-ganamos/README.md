# Landing GANAMOS

Sitio web para captación de usuarios con promoción de bono de bienvenida y testimonios en carrusel.

## Publicación

Este sitio puede ser publicado mediante GitHub Pages activando la opción en Settings > Pages y eligiendo la rama `main` y carpeta `/ (root)`.

